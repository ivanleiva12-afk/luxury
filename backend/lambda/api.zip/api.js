const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, GetCommand, PutCommand, DeleteCommand, QueryCommand } = require('@aws-sdk/lib-dynamodb');
const { S3Client, PutObjectCommand, GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);
const s3 = new S3Client({});

// Tablas
const TABLES = {
  profiles: 'salaoscura-profiles',
  users: 'salaoscura-users',
  registros: 'salaoscura-registros',
  config: 'salaoscura-config',
  messages: 'salaoscura-messages',
  media: 'salaoscura-media'
};

const S3_BUCKET = 'salaoscura-media';

const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event));
  
  const method = event.httpMethod;
  
  // Soporte para {proxy+} de API Gateway y invocación directa
  let pathParts;
  if (event.pathParameters && event.pathParameters.proxy) {
    // API Gateway {proxy+}: "users" o "users/123"
    pathParts = event.pathParameters.proxy.split('/').filter(p => p);
  } else {
    // Invocación directa o path normal: "/users" o "/users/123"
    pathParts = (event.path || '').split('/').filter(p => p);
  }
  
  const resource = pathParts[0]; // profiles, users, registros, etc.
  const id = pathParts[1];
  
  try {
    // CORS preflight
    if (method === 'OPTIONS') {
      return { statusCode: 200, headers, body: '' };
    }

    // ═══════════════════════════════════════════════════════════
    // PROFILES - Perfiles de escorts aprobados
    // ═══════════════════════════════════════════════════════════
    if (resource === 'profiles') {
      if (method === 'GET' && !id) {
        const result = await dynamodb.send(new ScanCommand({ TableName: TABLES.profiles }));
        return success(result.Items || []);
      }
      if (method === 'GET' && id) {
        const result = await dynamodb.send(new GetCommand({ TableName: TABLES.profiles, Key: { id } }));
        return result.Item ? success(result.Item) : notFound('Perfil no encontrado');
      }
      if (method === 'POST') {
        const body = JSON.parse(event.body);
        const item = { ...body, id: body.id || `profile-${Date.now()}`, createdAt: new Date().toISOString() };
        await dynamodb.send(new PutCommand({ TableName: TABLES.profiles, Item: item }));
        return success(item, 201);
      }
      if (method === 'PUT' && id) {
        const body = JSON.parse(event.body);
        const item = { ...body, id, updatedAt: new Date().toISOString() };
        await dynamodb.send(new PutCommand({ TableName: TABLES.profiles, Item: item }));
        return success(item);
      }
      if (method === 'DELETE' && id) {
        await dynamodb.send(new DeleteCommand({ TableName: TABLES.profiles, Key: { id } }));
        return success({ message: 'Eliminado' });
      }
    }

    // ═══════════════════════════════════════════════════════════
    // USERS - Usuarios para login (escorts aprobadas)
    // ═══════════════════════════════════════════════════════════
    if (resource === 'users') {
      if (method === 'GET' && !id) {
        const result = await dynamodb.send(new ScanCommand({ TableName: TABLES.users }));
        return success(result.Items || []);
      }
      if (method === 'GET' && id) {
        const result = await dynamodb.send(new GetCommand({ TableName: TABLES.users, Key: { id } }));
        return result.Item ? success(result.Item) : notFound('Usuario no encontrado');
      }
      if (method === 'POST') {
        const body = JSON.parse(event.body);
        const item = { ...body, id: body.id || body.email || `user-${Date.now()}`, createdAt: new Date().toISOString() };
        await dynamodb.send(new PutCommand({ TableName: TABLES.users, Item: item }));
        return success(item, 201);
      }
      if (method === 'PUT' && id) {
        const body = JSON.parse(event.body);
        const item = { ...body, id, updatedAt: new Date().toISOString() };
        await dynamodb.send(new PutCommand({ TableName: TABLES.users, Item: item }));
        return success(item);
      }
      if (method === 'DELETE' && id) {
        await dynamodb.send(new DeleteCommand({ TableName: TABLES.users, Key: { id } }));
        return success({ message: 'Eliminado' });
      }
    }

    // ═══════════════════════════════════════════════════════════
    // REGISTROS - Registros pendientes de aprobación
    // ═══════════════════════════════════════════════════════════
    if (resource === 'registros') {
      if (method === 'GET' && !id) {
        const result = await dynamodb.send(new ScanCommand({ TableName: TABLES.registros }));
        return success(result.Items || []);
      }
      if (method === 'GET' && id) {
        const result = await dynamodb.send(new GetCommand({ TableName: TABLES.registros, Key: { id } }));
        return result.Item ? success(result.Item) : notFound('Registro no encontrado');
      }
      if (method === 'POST') {
        const body = JSON.parse(event.body);
        const item = { ...body, id: body.id || `reg-${Date.now()}`, status: 'pending', createdAt: new Date().toISOString() };
        await dynamodb.send(new PutCommand({ TableName: TABLES.registros, Item: item }));
        return success(item, 201);
      }
      if (method === 'PUT' && id) {
        const body = JSON.parse(event.body);
        const item = { ...body, id, updatedAt: new Date().toISOString() };
        await dynamodb.send(new PutCommand({ TableName: TABLES.registros, Item: item }));
        return success(item);
      }
      if (method === 'DELETE' && id) {
        await dynamodb.send(new DeleteCommand({ TableName: TABLES.registros, Key: { id } }));
        return success({ message: 'Eliminado' });
      }
    }

    // ═══════════════════════════════════════════════════════════
    // CONFIG - Configuración del sitio
    // ═══════════════════════════════════════════════════════════
    if (resource === 'config') {
      if (method === 'GET' && !id) {
        const result = await dynamodb.send(new ScanCommand({ TableName: TABLES.config }));
        return success(result.Items || []);
      }
      if (method === 'GET' && id) {
        const result = await dynamodb.send(new GetCommand({ TableName: TABLES.config, Key: { key: id } }));
        return result.Item ? success(result.Item) : success({ key: id, value: null });
      }
      if (method === 'POST' || method === 'PUT') {
        const body = JSON.parse(event.body);
        const key = id || body.key;
        const item = { key, ...body, updatedAt: new Date().toISOString() };
        await dynamodb.send(new PutCommand({ TableName: TABLES.config, Item: item }));
        return success(item);
      }
    }

    // ═══════════════════════════════════════════════════════════
    // MESSAGES - Mensajes de contacto
    // ═══════════════════════════════════════════════════════════
    if (resource === 'messages') {
      if (method === 'GET' && !id) {
        const result = await dynamodb.send(new ScanCommand({ TableName: TABLES.messages }));
        return success(result.Items || []);
      }
      if (method === 'POST') {
        const body = JSON.parse(event.body);
        const item = { ...body, id: `msg-${Date.now()}`, createdAt: new Date().toISOString(), read: false };
        await dynamodb.send(new PutCommand({ TableName: TABLES.messages, Item: item }));
        return success(item, 201);
      }
      if (method === 'DELETE' && id) {
        await dynamodb.send(new DeleteCommand({ TableName: TABLES.messages, Key: { id } }));
        return success({ message: 'Eliminado' });
      }
    }

    // ═══════════════════════════════════════════════════════════
    // MEDIA - Fotos y videos (metadata + URLs firmadas para S3)
    // ═══════════════════════════════════════════════════════════
    if (resource === 'media') {
      // GET /media?userId=xxx - Obtener media de un usuario
      if (method === 'GET' && !id) {
        const userId = event.queryStringParameters?.userId;
        if (userId) {
          const result = await dynamodb.send(new ScanCommand({ 
            TableName: TABLES.media,
            FilterExpression: 'userId = :userId',
            ExpressionAttributeValues: { ':userId': userId }
          }));
          return success(result.Items || []);
        }
        const result = await dynamodb.send(new ScanCommand({ TableName: TABLES.media }));
        return success(result.Items || []);
      }
      
      // POST /media/upload-url - Generar URL firmada para subir a S3
      if (method === 'POST' && id === 'upload-url') {
        const body = JSON.parse(event.body);
        const { fileName, fileType, userId } = body;
        const key = `${userId}/${Date.now()}-${fileName}`;
        
        const command = new PutObjectCommand({
          Bucket: S3_BUCKET,
          Key: key,
          ContentType: fileType
        });
        
        const uploadUrl = await getSignedUrl(s3, command, { expiresIn: 3600 });
        const publicUrl = `https://${S3_BUCKET}.s3.amazonaws.com/${key}`;
        
        return success({ uploadUrl, publicUrl, key });
      }
      
      // POST /media - Guardar metadata del archivo subido
      if (method === 'POST' && !id) {
        const body = JSON.parse(event.body);
        const item = { 
          ...body, 
          id: `media-${Date.now()}`, 
          createdAt: new Date().toISOString() 
        };
        await dynamodb.send(new PutCommand({ TableName: TABLES.media, Item: item }));
        return success(item, 201);
      }
      
      // DELETE /media/{id}
      if (method === 'DELETE' && id) {
        await dynamodb.send(new DeleteCommand({ TableName: TABLES.media, Key: { id } }));
        return success({ message: 'Eliminado' });
      }
    }

    // ═══════════════════════════════════════════════════════════
    // AUTH - Autenticación simple
    // ═══════════════════════════════════════════════════════════
    if (resource === 'auth') {
      // POST /auth/login
      if (method === 'POST' && id === 'login') {
        const body = JSON.parse(event.body);
        const { email, password } = body;
        
        // Buscar usuario por email
        const result = await dynamodb.send(new ScanCommand({
          TableName: TABLES.users,
          FilterExpression: 'email = :email',
          ExpressionAttributeValues: { ':email': email }
        }));
        
        const user = result.Items?.[0];
        if (!user || user.password !== password) {
          return error('Credenciales inválidas', 401);
        }
        
        // No devolver password
        const { password: _, ...safeUser } = user;
        return success({ user: safeUser, token: `token-${Date.now()}` });
      }
    }

    return notFound('Ruta no encontrada');
    
  } catch (err) {
    console.error('Error:', err);
    return error(err.message, 500);
  }
};

// Helpers
function success(data, statusCode = 200) {
  return { statusCode, headers, body: JSON.stringify(data) };
}

function error(message, statusCode = 400) {
  return { statusCode, headers, body: JSON.stringify({ error: message }) };
}

function notFound(message) {
  return { statusCode: 404, headers, body: JSON.stringify({ error: message }) };
}
