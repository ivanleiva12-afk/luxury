const AWS = require('aws-sdk');
const s3 = new AWS.S3();

const BUCKET_NAME = 'salaoscura-media';
const REGION = 'us-east-1';

const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS'
};

exports.handler = async (event) => {
  const method = event.httpMethod;
  const path = event.path;

  try {
    if (method === 'OPTIONS') {
      return { statusCode: 200, headers, body: '' };
    }

    // POST /media/upload - Generar URL pre-firmada para subir archivo
    if (method === 'POST' && path === '/media/upload') {
      const body = JSON.parse(event.body);
      const { userId, fileName, fileType } = body;

      if (!userId || !fileName || !fileType) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'userId, fileName y fileType son requeridos' })
        };
      }

      // Generar key única: photos/userId/timestamp-fileName
      const timestamp = Date.now();
      const sanitizedName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
      const key = `photos/${userId}/${timestamp}-${sanitizedName}`;

      const params = {
        Bucket: BUCKET_NAME,
        Key: key,
        ContentType: fileType,
        Expires: 300 // URL válida por 5 minutos
      };

      const uploadUrl = await s3.getSignedUrlPromise('putObject', params);
      const publicUrl = `https://${BUCKET_NAME}.s3.${REGION}.amazonaws.com/${key}`;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ uploadUrl, publicUrl, key })
      };
    }

    // GET /media/{userId} - Listar fotos de un usuario
    if (method === 'GET' && path.startsWith('/media/')) {
      const userId = path.split('/')[2];

      if (!userId) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'userId requerido' }) };
      }

      const params = {
        Bucket: BUCKET_NAME,
        Prefix: `photos/${userId}/`
      };

      const result = await s3.listObjectsV2(params).promise();
      const files = (result.Contents || []).map(item => ({
        key: item.Key,
        url: `https://${BUCKET_NAME}.s3.${REGION}.amazonaws.com/${item.Key}`,
        size: item.Size,
        lastModified: item.LastModified
      }));

      return { statusCode: 200, headers, body: JSON.stringify(files) };
    }

    // DELETE /media - Eliminar archivo
    if (method === 'DELETE' && path === '/media') {
      const body = JSON.parse(event.body);
      const { key } = body;

      if (!key) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'key requerido' }) };
      }

      await s3.deleteObject({ Bucket: BUCKET_NAME, Key: key }).promise();

      return { statusCode: 200, headers, body: JSON.stringify({ message: 'Archivo eliminado' }) };
    }

    return { statusCode: 404, headers, body: JSON.stringify({ error: 'Ruta no encontrada' }) };

  } catch (error) {
    console.error('Error:', error);
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message }) };
  }
};
